import 'package:flutter/material.dart';

const Color white = Colors.white;
const Color black = Colors.black;

const TextStyle appBarHeading = TextStyle(color: white, fontSize: 30.0);
const TextStyle description = TextStyle(color: white, fontSize: 20.0);
