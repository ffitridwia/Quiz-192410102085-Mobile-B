import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:badges/badges.dart';
// ignore: unused_import
import 'package:fitri_store/models/product.dart';
import 'package:fitri_store/store/store.dart';
import 'package:fitri_store/widgets/product_list_item.dart';

class ProductListScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    var store = Provider.of<Store>(context);
    GlobalKey<ScaffoldState> _scaffoldKey = new GlobalKey<ScaffoldState>();

    return Scaffold(
      key: _scaffoldKey,
      bottomNavigationBar: BottomAppBar(
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceAround,
          children: [
            Text(
              "Total : ${store.getCartTotal().toStringAsFixed(2)}",
              textAlign: TextAlign.center,
              style: TextStyle(fontSize: 20, color: Colors.black),
            ),
            // ignore: deprecated_member_use
            RaisedButton(
              onPressed: () {
                // ignore: unused_local_variable
                // ignore: deprecated_member_use
                _scaffoldKey.currentState.showSnackBar(SnackBar(
                  content: Text('Thank you for shopping!'),
                  action: SnackBarAction(
                    label: 'Clear Cart',
                    onPressed: () {
                      store.clearCart();
                    },
                  ),
                ));
              },
              color: Colors.pink,
              child: Text("Checkout", style: TextStyle(color: Colors.white)),
            )
          ],
        ),
      ),
      appBar: AppBar(
        title: Text(
          "Fitri's Store",
        ),
        elevation: 0,
        actions: [
          Badge(
            showBadge: store.getCartQuantity() > 0,
            position: BadgePosition(top: 0, right: 2),
            animationType: BadgeAnimationType.scale,
            badgeContent: Text(
              store.getCartQuantity().toString(),
              style: TextStyle(color: Colors.white),
            ),
            child: IconButton(
              icon: Icon(
                Icons.shopping_cart,
                color: Colors.black45,
              ),
              onPressed: () {
                // ignore: unused_local_variable
                // ignore: deprecated_member_use
                _scaffoldKey.currentState.showSnackBar(SnackBar(
                  content: Text('Thank you for shopping!'),
                  action: SnackBarAction(
                    label: 'Clear Cart',
                    onPressed: () {
                      store.clearCart();
                    },
                  ),
                ));
              },
            ),
          ),
        ],
      ),
      backgroundColor: Colors.white,
      body: ListView(
        children: [
          Padding(
            padding: EdgeInsets.symmetric(horizontal: 20, vertical: 25),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text("Product List",
                    style: TextStyle(
                        fontWeight: FontWeight.bold,
                        fontSize: 30,
                        color: Colors.black87)),
              ],
            ),
          ),
          ...store.products.map((item) {
            return InkWell(
                onTap: () {
                  store.setActiveProduct(item);
                  Navigator.pushNamed(context, '/product');
                },
                child: ProductListItem(product: item));
          }),
        ],
      ),
    );
  }
}
