import 'package:flutter/material.dart';
import 'package:fitri_store/models/product.dart';
import 'package:lipsum/lipsum.dart' as lipsum;

class Store extends ChangeNotifier {
  List<Product> _products = [];
  List<Product> _cart = [];
  // ignore: avoid_init_to_null
  Product _active;

  Store() {
    _products = [
      Product(1, "Ariul Watermelon Hydro Glow Cream Moisturizing 25ml", 19000, 0, "hydroglow.png",
          lipsum.createParagraph()),
      Product(2, "Emina Capsule Treat Mask", 17100, 0, "green tea.jpg",
          lipsum.createParagraph()),
      Product(3, "Teddy Clubs Watermelon Lips Mask 10gr", 29000, 0, "lipmask.png",
          lipsum.createParagraph()),
      Product(4, "Neogen Dermalogy Bio Peel Gauze", 49000, 0, "neogen.jpeg",
          lipsum.createParagraph()),
      Product(5, "Scarlett Whitening Acne Serum", 35000, 0, "acneserum.jpg",
          lipsum.createParagraph()),
      Product(6, "Avoskin Your Skin Bae Lactic Acid 10% + Kiwi Fruit 5% + Niacinamide 2,5% High Dose Serum", 2500.00, 0, "avoskin.jpg",
          lipsum.createParagraph()),
      Product(7, "Emina Bright Stuff For Acne Prone Skin Moisturizing Cream", 21000, 0, "eminacream.jpg",
          lipsum.createParagraph()),
      Product(8, "BLP X Avoskin Multipurpose Tinted Sunscreen SPF50 30gr", 30000, 0, "tinted.jpg",
          lipsum.createParagraph()),
    ];
    notifyListeners();
  }

  List<Product> get products => _products;
  List<Product> get cart => _cart;
  Product get activeProduct => _active;

  setActiveProduct(Product product) {
    _active = product;
  }

  clearCart() {
    for (Product p in _products) {
      p.quantity = 0;
    }
    _cart.clear();
    notifyListeners();
  }

  addItemToCart(Product product) {
    print("adding ${product.name}");
    Product found =
        _cart.firstWhere((p) => p.id == product.id, orElse: () => null);
    if (found != null) {
      found.quantity += 1;
    } else {
      _cart.add(product);
      product.quantity += 1;
    }
    notifyListeners();
  }

  removeItemFromCart(Product product) {
    Product found =
        _cart.firstWhere((p) => p.id == product.id, orElse: () => null);
    if (found != null && found.quantity == 1) {
      product.quantity = 0;
      _cart.remove(product);
    }
    if (found != null && found.quantity > 1) {
      found.quantity -= 1;
    }
    notifyListeners();
  }

  int getCartQuantity() {
    int total = 0;
    for (Product p in _cart) {
      total += p.quantity;
    }
    return total;
  }

  double getCartTotal() {
    double price = 0;
    for (Product p in _cart) {
      price += (p.price * p.quantity);
    }
    return price;
  }
}
