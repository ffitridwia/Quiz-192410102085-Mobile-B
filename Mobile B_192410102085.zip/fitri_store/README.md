# e-Commerce Shop application with Flutter

![](https://img.shields.io/badge/Built%20with-Flutter-blue) [![Codemagic build status](https://api.codemagic.io/apps/5f68436bce8cd9b7f0095a7e/5f68436bce8cd9b7f0095a7d/status_badge.svg)](https://codemagic.io/apps/5f68436bce8cd9b7f0095a7e/5f68436bce8cd9b7f0095a7d/latest_build)

# Screen Record

![demo-gif](screenshots/play.gif)

# Build

[CodeMagic.io Automated Builds](https://codemagic.io/apps/5f68436bce8cd9b7f0095a7e/5f68436bce8cd9b7f0095a7d/latest_build) | Available in .APK and .APP formats
